/*jshint asi:true, expr:true, unused:false */
({
	mainConfigFile: 'require_config.js',
	name: 'lib/vendor/almond',
	include: 'lib/background',
	out: 'lib/build/background.js',

	optimize: 'none'
})
